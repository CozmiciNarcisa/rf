package ro.usv.rf;

import java.util.ArrayList;
import java.util.Arrays;

public class Neighbour implements Comparable<Neighbour>{
	double index;
	double distance;
	String className;
	public  int compareTo(Neighbour compareNeighbour) {
		return Double.compare(this.distance, compareNeighbour.distance);
	}

}
