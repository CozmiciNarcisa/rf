package ro.usv.rf;

public class DistanceUtils {
	public static double calculateDistanceEuclidian(double[] patern1, double[] patern2) {
		double Sum = 0.0;
		for (int i = 0; i < 2; i++) {
			Sum = Sum + Math.pow((patern1[i] - patern2[i]), 2.0);
		}
		return Math.sqrt(Sum);
	}

}
