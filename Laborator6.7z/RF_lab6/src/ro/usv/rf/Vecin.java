package ro.usv.rf;

public class Vecin implements Comparable<Vecin> {
	double nota;
	double distanta;
	String clasa;

	@Override
	public int compareTo(Vecin comparareVecin) {

		return Double.compare(this.distanta, comparareVecin.distanta);

	}

}
