package ro.usv.rf;

public class MainClass {

	public static void main(String[] args) {
		 double[][] learningSet = FileUtils.readLearningSetFromFile("in.txt");
		 FileUtils.writeLearningSetToFile("out.csv",normalizeLearningSet(learningSet)); 
	}
	
	
	private static double[][] normalizeLearningSet(double[][] learningSet) {
		double[][] normalizedLearningSet = new double[learningSet.length][learningSet[0].length];
		// .. enter your code here
		// xij = (xij-xjmin)/(xjmax-xjmin)
		for (int countLine = 0; countLine < learningSet.length; countLine++) {
			for (int countColumn = 0; countColumn < learningSet[0].length; countColumn++) {
				normalizedLearningSet[countLine][countColumn] = 
						(learningSet[countLine][countColumn] - ReturnMin(learningSet, countColumn))
								/ (ReturnMax(learningSet, countColumn)
										- ReturnMin(learningSet, countColumn));
			}
		}

		for (int i = 0; i < normalizedLearningSet.length; i++) {
			for (int j = 0; j < normalizedLearningSet[i].length; j++) {
				System.out.print(normalizedLearningSet[i][j] + " ");
			}
			System.out.println();
		}
		return normalizedLearningSet;
	}
	
	
	private static double ReturnMin(double[][] learningSet, int columnIndex) {
		double min = Integer.MAX_VALUE;
		for (int i = 0; i < learningSet.length; i++) {
			if (learningSet[i][columnIndex] < min)
				min = learningSet[i][columnIndex];
		}
		
		return min;
	}
	
	
	private static double ReturnMax(double[][] learningSet, int columnIndex) {
		double max = Integer.MIN_VALUE;
		for (int i = 0; i < learningSet.length; i++) {
			if (learningSet[i][columnIndex] > max)
				max = learningSet[i][columnIndex];
		}
	
		return max;
	}
	
}
